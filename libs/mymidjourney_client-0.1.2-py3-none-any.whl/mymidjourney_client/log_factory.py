import logging

logging.basicConfig(level="INFO")

logger = logging.getLogger(__name__)
